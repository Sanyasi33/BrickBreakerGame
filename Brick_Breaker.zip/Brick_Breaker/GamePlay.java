import java.awt.*;
import java.awt.Graphics2D;
//import java.awt.Color;
//import java.awt.Graphics;
import javax.swing.*;
import java.awt.event.*;
//import javax.swing.JPanel;
//import javax.swing.Timer;
public class GamePlay extends JPanel implements ActionListener,KeyListener
{
	private boolean play=false;
	private int totalBrick=21;
	private Timer timer;
	private int delay=8;
	private int ballposX=120;
	private int ballposY=350;
	private int ballXdir=-3;
	private int ballYdir=-3;
	private int playerX=350;
	private MapGenerator map;
	private int score=0;
	
	public GamePlay()
	{
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(true);
		Timer timer=new Timer(delay,this);
		timer.start();
		map=new MapGenerator(3,7);
	}
	public void paint(Graphics g)
	{
		//Background
		g.setColor(Color.black);
		g.fillRect(0,0,700,600);
		
		//Boarder
		g.setColor(Color.yellow);
		g.fillRect(0,0,700,5);
		g.fillRect(0,5,5,600);
		g.fillRect(680,5,5,600);
		//g.fillRect(0,560,700,5); (Down Boarder)
		
		//Paddle
		g.setColor(Color.green);
		g.fillRect(playerX,550,100,8);
		
		//Ball
		g.setColor(Color.red);
		g.fillOval(ballposX,ballposY,20,20);
		
		//Bricks
		map.draw((Graphics2D)g);
		
		//score
		g.setColor(Color.green);
		g.setFont(new Font("serif",Font.BOLD,25));
		g.drawString("score:"+score,580,30);
		
		//Name(Mr Sanny)
		g.setColor(Color.blue);
		g.setFont(new Font("serif",Font.BOLD,25));
		g.drawString("Developed by Mr Sanny",20,35);
		
		//gameover
		if(ballposY>=570)
		{
			play=false;
			ballXdir=0;
			ballYdir=0;
			g.setColor(Color.red);
			g.setFont(new Font("serif",Font.BOLD,40));
			g.drawString("GAME OVER !! SCORE: "+score,120,300);
			
			g.setColor(Color.green);
			g.setFont(new Font("serif",Font.BOLD,30));
			g.drawString("Press ENTER to restart",220,350);
		}
		
		//player won
		if(totalBrick<=0)
		{
			play=false;
			ballXdir=0;
			ballYdir=0;
			g.setColor(Color.green);
			g.setFont(new Font("serif",Font.BOLD,40));
			g.drawString("YOU WON !! SCORE: "+score,120,300);
			
			g.setColor(Color.green);
			g.setFont(new Font("serif",Font.BOLD,30));
			g.drawString("Press ENTER to restart",200,350);
		}
	}
	
	public void moveLeft()
	{
		playerX-=25;
	}
	public void moveRight()
	{
		playerX+=25;
	}
	public void keyPressed(KeyEvent e)
	{
		if(e.getKeyCode()==KeyEvent.VK_LEFT)
		{
			play=true;
			if(playerX<=0)
				playerX=0;
			else
				moveLeft();
		}
		if(e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			play=true;
			if(playerX>=585)
				playerX=585;
			else
				moveRight();
		}
		if(e.getKeyCode()==KeyEvent.VK_ENTER)
		{
			if(!play)
			{
				score=0;
				totalBrick=21;
				ballposX=120;
				ballposY=350;
				ballXdir=-3;
				ballYdir=-3;
				playerX=320;
				map= new MapGenerator(3,7);
			}
		}
		repaint();
	}
	public void actionPerformed(ActionEvent e)
	{
		if(play)
		{
			if(ballposX<=0)
			{
				ballXdir=-ballXdir;
			}
			if(ballposX>=660)
			{
				ballXdir=-ballXdir;
			}
			if(ballposY<=0)
			{
				ballYdir=-ballYdir;
			}
			Rectangle ballRect=new Rectangle(ballposX,ballposY,20,20);
			Rectangle paddleRect=new Rectangle(playerX,550,100,8);
			if(ballRect.intersects(paddleRect))
			{
				//ballXdir+=ballXdir; // own try for speedup ball movement
				//ballYdir+=ballYdir; // own try for speedup ball movement
				ballYdir=-ballYdir;
			}
			
			for(int i=0;i<map.map.length;i++)
			{
				for(int j=0;j<map.map[0].length;j++)
				{
					if(map.map[i][j]>0)
					{
						int width=map.brickWidth;
						int height=map.brickHeight;
						int brickXpos=80+j*width;
						int brickYpos=50+i*height;
						
						Rectangle brickRect=new Rectangle(brickXpos,brickYpos,width,height);
						if(ballRect.intersects(brickRect))
						{
							map.setBrick(0,i,j);
							totalBrick--;
							score=score+5; //score+=5;
							
							if(ballposX+19<=brickXpos || ballposX+1>=brickXpos+width)
							{
								ballXdir=-ballXdir;
							}
							else
							{
								ballYdir=-ballYdir;
							}
							//break A;
						}
					}
				}
			}	
			
			ballposX+=ballXdir;
			ballposY+=ballYdir;
		}
		repaint();
	}
	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e) {}
}